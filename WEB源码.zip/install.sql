-- MySQL dump 10.13  Distrib 5.5.62, for Linux (x86_64)
--
-- Host: localhost    Database: tlx
-- ------------------------------------------------------
-- Server version	5.5.62-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cloud_ads`
--

DROP TABLE IF EXISTS `cloud_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_ads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ads_name` varchar(20) NOT NULL,
  `ads_title` varchar(20) NOT NULL,
  `ads_url` varchar(500) NOT NULL,
  `ads_img` varchar(500) NOT NULL,
  `ads_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_ads`
--

LOCK TABLES `cloud_ads` WRITE;
/*!40000 ALTER TABLE `cloud_ads` DISABLE KEYS */;
/*!40000 ALTER TABLE `cloud_ads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_advise`
--

DROP TABLE IF EXISTS `cloud_advise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_advise` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `submit_time` datetime DEFAULT NULL,
  `submit_ip` varchar(20) NOT NULL DEFAULT '000.000.000.000',
  `content` varchar(200) DEFAULT '',
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='建议';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_advise`
--

LOCK TABLES `cloud_advise` WRITE;
/*!40000 ALTER TABLE `cloud_advise` DISABLE KEYS */;
/*!40000 ALTER TABLE `cloud_advise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_buyproxy`
--

DROP TABLE IF EXISTS `cloud_buyproxy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_buyproxy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proxy_id` int(11) NOT NULL,
  `price_type` int(11) NOT NULL,
  `proxy_money` decimal(10,2) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `count` int(11) NOT NULL,
  `software_name` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_buyproxy`
--

LOCK TABLES `cloud_buyproxy` WRITE;
/*!40000 ALTER TABLE `cloud_buyproxy` DISABLE KEYS */;
/*!40000 ALTER TABLE `cloud_buyproxy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_card`
--

DROP TABLE IF EXISTS `cloud_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time_str` varchar(20) NOT NULL COMMENT '中文充值卡',
  `card` varchar(12) NOT NULL COMMENT '卡密',
  `produce_time` datetime NOT NULL COMMENT '生成时间',
  `all_minutes` int(20) NOT NULL,
  `state` mediumint(1) NOT NULL COMMENT '0 代表已使用 1 未使用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_card`
--

LOCK TABLES `cloud_card` WRITE;
/*!40000 ALTER TABLE `cloud_card` DISABLE KEYS */;
INSERT INTO `cloud_card` VALUES (1,'43200年','FD40F970A3F2','2021-06-23 02:07:04',2147483647,1),(2,'43200年','4503E90EFBAC','2021-06-23 02:07:04',2147483647,1),(3,'43200年','4195CCF0B887','2021-06-23 02:07:04',2147483647,1),(4,'43200年','DA4A65D2956E','2021-06-23 02:07:04',2147483647,1),(5,'43200年','041D0726B58D','2021-06-23 02:07:04',2147483647,1),(6,'43200年','07876AD811DE','2021-06-23 02:07:04',2147483647,1),(7,'43200年','F19EE2BFB519','2021-06-23 02:07:04',2147483647,1),(8,'43200年','0397C85A061D','2021-06-23 02:07:04',2147483647,1),(9,'43200年','7DA68F1C8299','2021-06-23 02:07:04',2147483647,1),(10,'43200年','B117C2B15E5E','2021-06-23 02:07:04',2147483647,1),(11,'43200年','2B1655B7DCDE','2021-06-23 02:07:04',2147483647,1),(12,'43200年','BC97ADCEBEDA','2021-06-23 02:07:04',2147483647,1),(13,'43200年','CE8A519B82C9','2021-06-23 02:07:04',2147483647,1),(14,'43200年','6CAA069CE658','2021-06-23 02:07:04',2147483647,1),(15,'43200年','E4321AAD2A97','2021-06-23 02:07:04',2147483647,1),(16,'43200年','4B06F95CDBAC','2021-06-23 02:07:04',2147483647,1),(17,'43200年','7A53A5895BFE','2021-06-23 02:07:04',2147483647,1),(18,'43200年','41377BC9EACA','2021-06-23 02:07:04',2147483647,1),(19,'43200年','D928176634FA','2021-06-23 02:07:04',2147483647,1),(20,'43200年','F0E23A577E07','2021-06-23 02:07:04',2147483647,1),(21,'43200年','A960569826B3','2021-06-23 02:07:04',2147483647,1),(22,'43200年','DE3922EFBF19','2021-06-23 02:07:04',2147483647,1),(23,'43200年','7A6441F981B4','2021-06-23 02:07:04',2147483647,1),(24,'43200年','ADBE27D6EB3C','2021-06-23 02:07:04',2147483647,1),(25,'43200年','22DB680F7A4B','2021-06-23 02:07:04',2147483647,1),(26,'43200年','6876BA470D9D','2021-06-23 02:07:04',2147483647,1),(27,'43200年','451987524A7B','2021-06-23 02:07:04',2147483647,1),(28,'43200年','13ECD7E63AF2','2021-06-23 02:07:04',2147483647,1),(29,'43200年','5AB153EA17AF','2021-06-23 02:07:04',2147483647,1),(30,'43200年','A87860672E9D','2021-06-23 02:07:04',2147483647,1),(31,'43200年','24CFDB29F927','2021-06-23 02:07:04',2147483647,1),(32,'43200年','57B39531C09C','2021-06-23 02:07:04',2147483647,1),(33,'43200年','6A5C89C99D58','2021-06-23 02:07:04',2147483647,1),(34,'43200年','98739314AF12','2021-06-23 02:07:04',2147483647,1),(35,'43200年','C9233E3525A9','2021-06-23 02:07:04',2147483647,1),(36,'43200年','060796A00198','2021-06-23 02:07:04',2147483647,1),(37,'43200年','4728C7CC12A5','2021-06-23 02:07:04',2147483647,1),(38,'43200年','177CDA9B3296','2021-06-23 02:07:04',2147483647,1),(39,'43200年','D55ACE2CC8B5','2021-06-23 02:07:04',2147483647,1),(40,'43200年','0BA280EBA36A','2021-06-23 02:07:04',2147483647,1),(41,'43200年','3724BC4BF723','2021-06-23 02:07:04',2147483647,1),(42,'43200年','863324BD3B7E','2021-06-23 02:07:04',2147483647,1),(43,'43200年','F321F920A34F','2021-06-23 02:07:04',2147483647,1),(44,'43200年','2F61F32BD6D8','2021-06-23 02:07:04',2147483647,1),(45,'43200年','92719568B1B2','2021-06-23 02:07:04',2147483647,1),(46,'43200年','18FD055BAA6D','2021-06-23 02:07:04',2147483647,1),(47,'43200年','19A88D71A4B8','2021-06-23 02:07:04',2147483647,1),(48,'43200年','003B08C61AA5','2021-06-23 02:07:04',2147483647,1),(49,'43200年','D142714FD662','2021-06-23 02:07:04',2147483647,1),(50,'43200年','4615C72E1AA1','2021-06-23 02:07:04',2147483647,1),(51,'43200年','08BAA8DA7D47','2021-06-23 02:07:04',2147483647,1),(52,'43200年','D0B42987D7A9','2021-06-23 02:07:04',2147483647,1),(53,'43200年','04830EDE7D39','2021-06-23 02:07:04',2147483647,1),(54,'43200年','C52C0A00FCE0','2021-06-23 02:07:04',2147483647,1),(55,'43200年','15762951EE0F','2021-06-23 02:07:04',2147483647,1),(56,'43200年','A9E6B70609F8','2021-06-23 02:07:04',2147483647,1),(57,'43200年','15FF01550517','2021-06-23 02:07:04',2147483647,1),(58,'43200年','D0CD9ACF0A0D','2021-06-23 02:07:04',2147483647,1),(59,'43200年','81AB87872EC6','2021-06-23 02:07:04',2147483647,1),(60,'43200年','94E6249682AE','2021-06-23 02:07:04',2147483647,1),(61,'43200年','A58534F6968C','2021-06-23 02:07:04',2147483647,1),(62,'43200年','2485E1B926FD','2021-06-23 02:07:04',2147483647,1),(63,'43200年','EF955EBBFC00','2021-06-23 02:07:04',2147483647,1),(64,'43200年','4CF781C4168E','2021-06-23 02:07:04',2147483647,1),(65,'43200年','4A33D8E08E30','2021-06-23 02:07:04',2147483647,1),(66,'43200年','57BA67352365','2021-06-23 02:07:04',2147483647,1),(67,'43200年','B92C9D856638','2021-06-23 02:07:04',2147483647,1),(68,'43200年','276090BFE8E9','2021-06-23 02:07:04',2147483647,1),(69,'43200年','B0F8722CB11D','2021-06-23 02:07:04',2147483647,1),(70,'43200年','CBD0706B227E','2021-06-23 02:07:04',2147483647,1),(71,'43200年','52A72E49AA15','2021-06-23 02:07:04',2147483647,1),(72,'43200年','0E7A3DDFDD32','2021-06-23 02:07:04',2147483647,1),(73,'43200年','7D59EB182076','2021-06-23 02:07:04',2147483647,1),(74,'43200年','3DE3804A7860','2021-06-23 02:07:04',2147483647,1),(75,'43200年','2DA67B4FEA71','2021-06-23 02:07:04',2147483647,1),(76,'43200年','5EFC89E82A9D','2021-06-23 02:07:04',2147483647,1),(77,'43200年','55512661570E','2021-06-23 02:07:04',2147483647,1),(78,'43200年','1EA013258420','2021-06-23 02:07:04',2147483647,1),(79,'43200年','70FA6166B8A1','2021-06-23 02:07:04',2147483647,1),(80,'43200年','9CC7701BCE07','2021-06-23 02:07:04',2147483647,1),(81,'43200年','2C552FC61605','2021-06-23 02:07:04',2147483647,1),(82,'43200年','EAB8FFD7F0F2','2021-06-23 02:07:04',2147483647,1),(83,'43200年','8E97E9BE83E9','2021-06-23 02:07:04',2147483647,1),(84,'43200年','20A40970CAA0','2021-06-23 02:07:04',2147483647,1),(85,'43200年','F5F64F5F54A5','2021-06-23 02:07:04',2147483647,1),(86,'43200年','E7284AC7DFD2','2021-06-23 02:07:04',2147483647,1),(87,'43200年','79638C5A9556','2021-06-23 02:07:04',2147483647,1),(88,'43200年','15E3145C593E','2021-06-23 02:07:04',2147483647,1),(89,'43200年','3EFA64B3A6FC','2021-06-23 02:07:04',2147483647,1),(90,'43200年','6BAF39826BE0','2021-06-23 02:07:04',2147483647,1),(91,'43200年','5CC89A367813','2021-06-23 02:07:04',2147483647,1),(92,'43200年','DF5565719851','2021-06-23 02:07:04',2147483647,1),(93,'43200年','0B1C5B35E605','2021-06-23 02:07:04',2147483647,1),(94,'43200年','6E8DDA38D3B7','2021-06-23 02:07:04',2147483647,1),(95,'43200年','921F9E56C8B9','2021-06-23 02:07:04',2147483647,1),(96,'43200年','1633D105FB82','2021-06-23 02:07:04',2147483647,1),(97,'43200年','7D0D596E8BC1','2021-06-23 02:07:04',2147483647,1),(98,'43200年','E2F7FF08F875','2021-06-23 02:07:04',2147483647,1),(99,'43200年','9505F75B6892','2021-06-23 02:07:04',2147483647,1),(100,'43200年','51BD436A1F5B','2021-06-23 02:07:04',2147483647,1),(101,'1年','4FE14CE123E6','2021-06-23 02:19:30',525600,0),(102,'1年','07EE8092C24A','2021-06-23 02:19:30',525600,0),(103,'1年','25381A1B8364','2021-06-23 02:19:30',525600,0);
/*!40000 ALTER TABLE `cloud_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_model`
--

DROP TABLE IF EXISTS `cloud_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0系统模块1自定义模块',
  `model_title` varchar(200) NOT NULL,
  `model_describe` varchar(200) NOT NULL,
  `model_whole_name` varchar(200) DEFAULT NULL,
  `model_single_code` varchar(500) NOT NULL,
  `model_dex_url` varchar(500) NOT NULL,
  `model_res_url` varchar(500) DEFAULT NULL,
  `model_xml` varchar(500) DEFAULT NULL,
  `model_state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0关闭1开启',
  `model_vip` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0普通1商户',
  `model_img` varchar(500) NOT NULL,
  `model_config_rule` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_model`
--

LOCK TABLES `cloud_model` WRITE;
/*!40000 ALTER TABLE `cloud_model` DISABLE KEYS */;
/*!40000 ALTER TABLE `cloud_model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_notice`
--

DROP TABLE IF EXISTS `cloud_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_notice` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `creat_time` varchar(20) NOT NULL DEFAULT '' COMMENT '创建时间',
  `title` varchar(200) NOT NULL DEFAULT '' COMMENT '标题',
  `content` varchar(200) NOT NULL DEFAULT '' COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='公告表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_notice`
--

LOCK TABLES `cloud_notice` WRITE;
/*!40000 ALTER TABLE `cloud_notice` DISABLE KEYS */;
INSERT INTO `cloud_notice` VALUES (2,'2021-06-23 01:30:30','点我查看公告','请下载注入器配套使用~！\n\nhttps://ravey.lanzoui.com/iQ7A2qlpf2j');
/*!40000 ALTER TABLE `cloud_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_price`
--

DROP TABLE IF EXISTS `cloud_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `soft_id` int(11) NOT NULL,
  `hour` int(11) NOT NULL,
  `day` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `season` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `proxy_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_price`
--

LOCK TABLES `cloud_price` WRITE;
/*!40000 ALTER TABLE `cloud_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `cloud_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_proxy`
--

DROP TABLE IF EXISTS `cloud_proxy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_proxy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `frozen` int(1) NOT NULL,
  `soft` varchar(100) NOT NULL,
  `user_id` int(10) NOT NULL DEFAULT '0',
  `is_addproxy` tinyint(1) NOT NULL,
  `proxy_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_proxy`
--

LOCK TABLES `cloud_proxy` WRITE;
/*!40000 ALTER TABLE `cloud_proxy` DISABLE KEYS */;
/*!40000 ALTER TABLE `cloud_proxy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_recommendedrule`
--

DROP TABLE IF EXISTS `cloud_recommendedrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_recommendedrule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `origin_day` int(4) NOT NULL DEFAULT '0' COMMENT '原本时长',
  `give_day` int(4) NOT NULL DEFAULT '0' COMMENT '赠送时长',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='被推荐人规则';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_recommendedrule`
--

LOCK TABLES `cloud_recommendedrule` WRITE;
/*!40000 ALTER TABLE `cloud_recommendedrule` DISABLE KEYS */;
/*!40000 ALTER TABLE `cloud_recommendedrule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_recommenderrule`
--

DROP TABLE IF EXISTS `cloud_recommenderrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_recommenderrule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `origin_day` int(4) unsigned NOT NULL DEFAULT '0' COMMENT '原本时长',
  `give_day` int(4) unsigned NOT NULL DEFAULT '0' COMMENT '赠送时长',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='推荐人规则';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_recommenderrule`
--

LOCK TABLES `cloud_recommenderrule` WRITE;
/*!40000 ALTER TABLE `cloud_recommenderrule` DISABLE KEYS */;
/*!40000 ALTER TABLE `cloud_recommenderrule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_regcode`
--

DROP TABLE IF EXISTS `cloud_regcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_regcode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `software_id` int(11) NOT NULL COMMENT '软件id',
  `time_str` varchar(10) NOT NULL DEFAULT '' COMMENT '中文时间',
  `software_name` varchar(20) NOT NULL DEFAULT '' COMMENT '软件名',
  `code` char(32) NOT NULL DEFAULT '' COMMENT '注册码',
  `produce_time` datetime DEFAULT NULL COMMENT '生成时间',
  `all_minutes` int(10) unsigned DEFAULT '0' COMMENT '可用分钟',
  `isonline` mediumint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0不在线，1在线',
  `overdue` mediumint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0未到期，1到期',
  `computer_uid` char(50) NOT NULL DEFAULT '' COMMENT '机器码',
  `beginuse_time` datetime DEFAULT NULL COMMENT '开始使用时间',
  `expire_time` datetime DEFAULT NULL COMMENT '到期时间',
  `last_time` datetime DEFAULT NULL COMMENT '上次登录时间',
  `last_ip` varchar(20) NOT NULL DEFAULT '000.000.000.000' COMMENT '最后一次登录ip',
  `use_count` int(10) unsigned DEFAULT '0' COMMENT '使用次数',
  `frozen` mediumint(1) NOT NULL DEFAULT '0' COMMENT '0 正常1冻结',
  `token` char(5) DEFAULT NULL COMMENT '限制多开',
  `mark` char(30) NOT NULL DEFAULT '' COMMENT '备注',
  `recommend_code` int(10) DEFAULT NULL COMMENT '推荐码',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='注册码表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_regcode`
--

LOCK TABLES `cloud_regcode` WRITE;
/*!40000 ALTER TABLE `cloud_regcode` DISABLE KEYS */;
INSERT INTO `cloud_regcode` VALUES (12,8,5,'10年','测试','6834930D4AB185BC0795239A','2021-06-23 02:20:21',5256000,1,0,'FD7BAABA27D893D530B00D20ABBD866B','2021-06-23 02:20:32','2031-06-21 02:20:32','2021-06-23 02:20:32','192.168.0.101',1,0,'09c6d','',NULL);
/*!40000 ALTER TABLE `cloud_regcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_software`
--

DROP TABLE IF EXISTS `cloud_software`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_software` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL COMMENT '软件名',
  `version` varchar(10) DEFAULT '' COMMENT '软件版本',
  `info` varchar(45) DEFAULT '' COMMENT '软件公告',
  `update_url` varchar(45) DEFAULT '' COMMENT '更新地址',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `user_id` int(10) unsigned NOT NULL COMMENT '用户id',
  `try_minutes` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '试用分钟',
  `try_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '试用次数',
  `updatemode` mediumint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0强制更新1不强制',
  `bindmode` mediumint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0绑机单开1绑机多开2不绑多开',
  `unbindmode` mediumint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0允许解绑1不允许',
  `frozen` mediumint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 正常1冻结',
  `updatamsg` varchar(100) NOT NULL COMMENT '更新提示信息',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `sy` mediumint(1) NOT NULL COMMENT '是否开启试用',
  `web` mediumint(1) NOT NULL COMMENT '是否开启发卡网',
  `weburl` varchar(100) NOT NULL COMMENT '发卡网',
  `hint` varchar(50) NOT NULL COMMENT '提示信息',
  `textcolor` varchar(50) NOT NULL COMMENT '字体颜色',
  `showad` mediumint(1) NOT NULL COMMENT '是否显示广告条',
  `jmkey` varchar(50) NOT NULL COMMENT '抽代码key',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_software`
--

LOCK TABLES `cloud_software` WRITE;
/*!40000 ALTER TABLE `cloud_software` DISABLE KEYS */;
INSERT INTO `cloud_software` VALUES (3,'1','1','','','2021-06-23 01:50:52',1,30,2,0,0,0,0,'','天狼星网络验证',1,1,'http://nbsl.z74d.cn/','请输入注册码','#000000',0,''),(5,'测试','2','','','2021-06-23 02:14:34',8,30,2,0,0,0,0,'','天狼星网络验证',0,1,'','请输入注册码','#000000',0,''),(6,'dragon','1','6666','','2021-06-23 02:24:54',10,30,2,0,0,0,0,'','郎',1,1,'','请输入注册码','#004986',0,''),(7,'零秒天空脚本','1','','','2021-06-23 02:25:20',7,10,1,0,0,0,0,'','认准玖韩',0,1,'','请输入卡密','#00ffff',0,'');
/*!40000 ALTER TABLE `cloud_software` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_trial`
--

DROP TABLE IF EXISTS `cloud_trial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_trial` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `computer_uid` char(16) DEFAULT '0' COMMENT '机器码',
  `software_id` int(11) DEFAULT '0' COMMENT '软件id',
  `has_try_count` int(11) DEFAULT '1' COMMENT '已用次数',
  `last_ip` varchar(20) DEFAULT '000.000.000.000' COMMENT 'ip',
  `last_time` datetime DEFAULT NULL COMMENT '最后试用时间',
  `token` char(5) DEFAULT NULL COMMENT '限制多开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_trial`
--

LOCK TABLES `cloud_trial` WRITE;
/*!40000 ALTER TABLE `cloud_trial` DISABLE KEYS */;
INSERT INTO `cloud_trial` VALUES (1,'FD7BAABA27D893D5',5,1,'192.168.0.101','2021-06-23 02:19:39','581ba');
/*!40000 ALTER TABLE `cloud_trial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_user`
--

DROP TABLE IF EXISTS `cloud_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL DEFAULT '',
  `password` char(40) NOT NULL DEFAULT '',
  `email` varchar(30) NOT NULL DEFAULT '',
  `reg_time` datetime DEFAULT NULL,
  `lastlogin_time` datetime DEFAULT NULL COMMENT '上一次登录时间',
  `lastlogin_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '上一次登录ip',
  `currentlogin_time` datetime DEFAULT NULL COMMENT '本次登录时间',
  `currentlogin_ip` varchar(20) NOT NULL DEFAULT '' COMMENT '本次登录ip',
  `login_count` int(10) unsigned DEFAULT NULL,
  `forget_time` datetime DEFAULT NULL COMMENT '上次找回密码时间',
  `vip` mediumint(1) NOT NULL COMMENT '授权用户',
  `expire_time` datetime DEFAULT NULL COMMENT '到期时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_user`
--

LOCK TABLES `cloud_user` WRITE;
/*!40000 ALTER TABLE `cloud_user` DISABLE KEYS */;
INSERT INTO `cloud_user` VALUES (1,'paper888','906e75654412ae98d8413e714444d892f3aaa801','2441800534@qq.com','2020-01-04 21:25:11','2021-06-23 02:05:28','180.138.18.5','2021-06-23 02:28:41','180.138.18.5',13,NULL,1,'2099-12-30 00:00:00'),(6,'994993085','3432d52f8e3f7653ca267f63b643ece6fb0032b5','994993085@qq.com','2021-06-23 01:59:07',NULL,'',NULL,'',NULL,NULL,1,'2021-06-23 01:59:07'),(7,'714111222','b654d5eb78583e52f052f1e1003f120aae5e0274','412978442@qq.com','2021-06-23 01:59:16','2021-06-23 02:26:18','111.37.128.63','2021-06-23 02:37:10','111.37.128.63',3,NULL,1,'2022-06-23 02:20:50'),(8,'xiaoxigua','7609b3502d1cddad77765a1ce524711c38c3037d','2591097801@qq.com','2021-06-23 02:02:10','2021-06-23 02:05:26','','2021-06-23 02:05:26','112.194.216.118',1,NULL,1,'2121-05-30 02:05:14'),(9,'Tears20','1738ba93ca0d9bf3fd421b811bc7b3f71987fac1','2992675357@qq.com','2021-06-23 02:02:50','2021-06-23 02:21:44','117.136.122.182','2021-06-23 02:22:19','117.136.122.182',2,NULL,1,'2022-06-23 02:21:08'),(10,'1504243409','b4006210f7fc599ce321e10899ce99a4819b5942','1504243409@qq.com','2021-06-23 02:03:38','2021-06-23 02:20:59','','2021-06-23 02:20:59','111.34.97.237',1,NULL,1,'2022-06-23 02:20:34'),(11,'lingfeng','ea481091a67aee44304081df58d07b693f7a4f02','1812222111@qq.com','2021-06-23 02:15:28',NULL,'',NULL,'',NULL,NULL,1,'2021-06-23 02:15:28');
/*!40000 ALTER TABLE `cloud_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_version`
--

DROP TABLE IF EXISTS `cloud_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ver_name` varchar(50) NOT NULL COMMENT '版本名',
  `ver_msg` varchar(500) NOT NULL COMMENT '更新内容',
  `ver_number` int(11) NOT NULL DEFAULT '0' COMMENT '版本号',
  `ver_address` varchar(500) NOT NULL COMMENT '下载地址',
  `ver_state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 关闭 / 1 开启',
  `ver_force` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 可选/ 1 强制',
  `ver_md5` varchar(50) NOT NULL COMMENT '版本MD5',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_version`
--

LOCK TABLES `cloud_version` WRITE;
/*!40000 ALTER TABLE `cloud_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `cloud_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'tlx'
--

--
-- Dumping routines for database 'tlx'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-23  2:45:05
