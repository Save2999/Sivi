<?php if (!defined('THINK_PATH')) exit();?><div class="layuimini-container">
    <div class="layuimini-main">
	    <div class="layui-btn-group">
            <button class="layui-btn data-add-btn">添加新版本</button>
        </div>
		<table class="layui-hide" id="currentTableId" lay-filter="currentTableFilter"></table>
        <script type="text/html" id="currentTableBar">
            <a class="layui-btn layui-btn-xs data-count-edit" lay-event="edit">编辑</a>
            <a class="layui-btn layui-btn-xs layui-btn-danger data-count-delete" lay-event="delete">删除</a>
        </script>
    </div>
</div>
<script class="EditVersionInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="VersionInfo">
		                 <div class="layui-hide">
                              <label class="layui-form-label">ID</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled"  type="text" name="id" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">版本名</label>
                              <div class="layui-input-block">
                                   <input type="text" lay-verify="required" name="ver_name" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
		                 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">更新内容</label>
                              <div class="layui-input-block">
                                   <textarea name="ver_msg" lay-verify="required" class="layui-textarea"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">版本号</label>
                              <div class="layui-input-block">
                                   <input type="text" lay-verify="required|number" name="ver_number" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">下载地址</label>
                              <div class="layui-input-block">
                                   <input type="text" lay-verify="required|url" name="ver_address" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">状态</label>
							  <div class="layui-input-block">
                                   <input type="radio" name="ver_state" value="0" title="停用" checked="">
                                   <input type="radio" name="ver_state" value="1" title="正常">
                              </div>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">强制更新</label>
							  <div class="layui-input-block">
                                   <input type="radio" name="ver_force" value="0" title="可选" checked="">
                                   <input type="radio" name="ver_force" value="1" title="强制">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">MD5</label>
                              <div class="layui-input-block">
                                   <input type="text" lay-verify="required" name="ver_md5" autocomplete="off"  class="layui-input">
                              </div>
                         </div> 
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="submit"></button>
                         </div>
				   </form>
</script>
<script class="AddVersionInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="VersionInfo">
		                 <div class="layui-form-item">
                              <label class="layui-form-label">版本名</label>
                              <div class="layui-input-block">
                                   <input type="text" lay-verify="required" name="ver_name" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
		                 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">更新内容</label>
                              <div class="layui-input-block">
                                   <textarea name="ver_msg" lay-verify="required" class="layui-textarea"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">版本号</label>
                              <div class="layui-input-block">
                                   <input type="text" lay-verify="required|number" name="ver_number" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">下载地址</label>
                              <div class="layui-input-block">
                                   <input type="text" lay-verify="required|url" name="ver_address" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">状态</label>
							  <div class="layui-input-block">
                                   <input type="radio" name="ver_state" value="0" title="停用" checked="">
                                   <input type="radio" name="ver_state" value="1" title="正常">
                              </div>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">强制更新</label>
							  <div class="layui-input-block">
                                   <input type="radio" name="ver_force" value="0" title="可选" checked="">
                                   <input type="radio" name="ver_force" value="1" title="强制">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">MD5</label>
                              <div class="layui-input-block">
                                   <input type="text" lay-verify="required" name="ver_md5" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="add_version"></button>
                         </div>
				   </form>
</script>
<script>
    layui.use(['form', 'table'], function () {
        var $ = layui.jquery,
            form = layui.form,
            table = layui.table;
		form.render();
		//取数据
        table.render({
            elem: '#currentTableId',
            url: './Home/Version/VersionList',
			height: 500,
			loading: true,
			method: 'post',
			limits: [10],
            limit: 10,
			cellMinWidth: 80,
            page: true,
            cols: [[
                {field: 'id',width: 60, title: 'ID', sort: true},
				{field: 'ver_name', title: '版本名'},
                {field: 'ver_msg', title: '更新内容'},
				{field: 'ver_number', title: '版本号'},
				{field: 'ver_address', title: '下载地址'},
				{field: 'ver_state', title: '状态',templet:function(rec){
							if(rec.ver_state=='0')
							   return "停用";
							else if(rec.ver_state=='1')
							   return "正常";
							else
							   return rec.ver_state;
        		}},
				{field: 'ver_force', title: '强制更新',templet:function(rec){
							if(rec.ver_force=='0')
							   return "可选";
							else if(rec.ver_force=='1')
							   return "强制";
							else
							   return rec.ver_force;
        		}},
				{field: 'ver_md5', title: 'MD5'},
                {title: '操作', minWidth: 120, templet: '#currentTableBar', fixed: "right", align: "center"}
            ]]
        });
		$(".data-add-btn").on("click", function () {
            layer.open({
                     content: $('.AddVersionInfo').html()
					 ,title: '添加新版本'
                     ,btn: ['提交', '取消']
					 ,success: function(layero, index){
					       form.render();
                     }
                     ,yes: function(res,layero){
					       layero.find('form').find('button[lay-submit]').click();
						   return false;
                     }
               });
        });
		form.on('submit(add_version)', function (data) {
		    var loading = layer.load(0, {
                        shade: false
                    });
			$.ajax({
                      url:"./Home/Version/AddVersion",
                      method:'post',
                      data:data.field,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
                        layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
            return false;
        });
		form.on('submit(submit)', function (data) {
		    var loading = layer.load(0, {
                        shade: false
                    });
			$.ajax({
                      url:"./Home/Version/EditVersion",
                      method:'post',
                      data:data.field,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
                        layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
            return false;
        });
        table.on('tool(currentTableFilter)', function (obj) {
            var data = obj.data;
            if (obj.event === 'edit') {
				layer.open({
                     content: $('.EditVersionInfo').html()
					 ,title: '编辑 '+data.ver_name
                     ,btn: ['提交修改', '取消']
					 ,success: function(layero, index){
							   form.val('VersionInfo', {
                                        "id": data.id,
										"ver_name": data.ver_name,
										"ver_msg": data.ver_msg,
										"ver_number": data.ver_number,
										"ver_address": data.ver_address,
										"ver_state": data.ver_state,
										"ver_force": data.ver_force,
										"ver_md5": data.ver_md5
                                        										
                               })
                     }
                     ,yes: function(res,layero){
					       layero.find('form').find('button[lay-submit]').click();
						   return false;
                     }
               });
            } else if (obj.event === 'delete') {
                layer.confirm('是否删除 '+data.ver_name, function (index) {
                    obj.del();
                    layer.close(index);
					var loading = layer.load(0, {
                        shade: false
                    });
					$.ajax({
                      url:"./Home/Version/VersionDel",
                      method:'post',
                      data:data,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
                        if(result.status==0){
                           layer.msg(result.msg);
                          }
                        else
                          layer.msg(result.msg);
						layer.close(loading);
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
                });
            }
        });

    });
</script>