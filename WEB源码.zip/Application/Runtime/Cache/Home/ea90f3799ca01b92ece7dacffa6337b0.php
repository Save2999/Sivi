<?php if (!defined('THINK_PATH')) exit();?><div class="layuimini-container">
    <div class="layuimini-main">

        <fieldset class="layui-elem-field layuimini-search">
            <legend>搜索信息</legend>
            <div style="margin: 10px 10px 10px 10px">
                <form class="layui-form layui-form-pane" action="">
                    <div class="layui-form-item">
                        <div class="layui-inline">
                            <label class="layui-form-label">用户名</label>
                            <div class="layui-input-inline">
                                <input type="text" name="username" lay-verify="required" autocomplete="off" class="layui-input">
                            </div>
                        </div>
                        <div class="layui-inline">
                            <a class="layui-btn" lay-submit="" lay-filter="data-search-btn">搜索</a>
                        </div>
                    </div>
                </form>
            </div>
        </fieldset>
		
        <table class="layui-hide" id="currentTableId" lay-filter="currentTableFilter"></table>
        <script type="text/html" id="currentTableBar">
            <a class="layui-btn layui-btn-xs data-count-edit" lay-event="edit">编辑</a>
            <a class="layui-btn layui-btn-xs layui-btn-danger data-count-delete" lay-event="delete">删除</a>
        </script>
    </div>
</div>
<script class="UserInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="SoftInfo">
				         <div class="layui-form-item">
                              <label class="layui-form-label">用户名</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled" type="text" name="username"  autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">邮箱</label>
                              <div class="layui-input-inline">
                                   <input type="text" name="email" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">注册时间</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled" type="text" name="reg_time" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">登录时间</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled" type="text" name="currentlogin_time" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">登录IP</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled" type="text" name="lastlogin_ip" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">当前登录IP</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled" type="text" name="currentlogin_ip" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">登录次数</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled" type="text" name="login_count" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">找回密码</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled" type="text" name="forget_time" autocomplete="off" class="layui-input">
                              </div>
                         </div>
						 <!--<div class="layui-form-item">-->
                              <!--<label class="layui-form-label">可用时间</label>-->
                              <!--<div class="layui-input-inline">-->
                                   <!--<input onfocus="this.blur();" type="text" id="expiretime" name="expire_time" lay-verify="required" lay-reqtext="" autocomplete="off" class="layui-input">-->
                              <!--</div>-->
                         <!--</div>-->
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="submit"></button>
                         </div>
		 </form>
</script>
<script src="/static/lib/laydate/laydate.js"></script>
<script>
    layui.use(['form', 'table'], function () {
        var $ = layui.jquery,
            form = layui.form,
            table = layui.table;
		var laydate = layui.laydate;
        table.render({
            elem: '#currentTableId',
            url: './Home/Admin/table',
			height: 500,
			loading: true,
			method: 'post',
			limits: [10],
            limit: 10,
			cellMinWidth: 80,
            page: true,
            cols: [[
                {field: 'id', width: 60,  title: 'ID', sort: true},
                {field: 'username', title: '用户名'},
				{field: 'email', title: '邮箱'},
                {field: 'reg_time',  title: '注册时间'},
                {field: 'lastlogin_time',  title: '最近登录时间'},
                {field: 'login_count',  title: '登录次数', sort: true},
                {field: 'lastlogin_ip',  title: '登录IP'},
                // {field: 'expire_time',  title: '到期时间'},
                {title: '操作',  minWidth: 120, templet: '#currentTableBar', fixed: "right", align: "center"}
            ]]
        });
        form.on('submit(data-search-btn)', function (data) {
            var result = JSON.stringify(data.field);
            table.reload('currentTableId', {
                page: {
                    curr: 1
                }
                , where: {
                    searchParams: result
                }
            }, 'data');

            return false;
        });
		form.on('submit(submit)', function (data) {
		    var loading = layer.load(0, {
                    shade: false
                });
			$.ajax({
                      url:"./Home/Admin/EditUser",
                      method:'post',
                      data:data.field,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
						layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
            return false;
        });
        table.on('tool(currentTableFilter)', function (obj) {
            var data = obj.data;
            if (obj.event === 'edit') {
				layer.open({
                     content: $('.UserInfo').html()
					 ,title: '编辑 '+data.username
                     ,btn: ['提交修改', '取消']
					 ,success: function(layero, index){
							   laydate.render({
                                   elem: '#expiretime'
                                   ,type: 'datetime'
                               });
							   form.val('SoftInfo', {
                                        "username": data.username,
										"email": data.email,
										"reg_time": data.reg_time,
										"currentlogin_time": data.currentlogin_time,
										"lastlogin_ip": data.lastlogin_ip,
										"currentlogin_ip": data.currentlogin_ip,
										"login_count": data.login_count,
										"forget_time": data.forget_time,
										"expire_time": data.expire_time
                                        										
                               })
                     }
                     ,yes: function(res,layero){
					       layero.find('form').find('button[lay-submit]').click();
						   return false;
                     }
               });
            } else if (obj.event === 'delete') {
                layer.confirm('是否删除 '+data.username+' 用户', function (index) {
                    obj.del();
                    layer.close(index);
					var loading = layer.load(0, {
                        shade: false
                    });
					$.ajax({
                      url:"./Home/Admin/UserDel",
                      method:'post',
                      data:data,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
                        layer.msg(result.msg);
						layer.close(loading);
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
                });
            }
        });

    });
</script>