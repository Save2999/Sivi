<?php if (!defined('THINK_PATH')) exit();?><link rel="stylesheet" href="/Public/css/a100e2e6.app.css">
<link rel="stylesheet" href="/Public/css/common.css">
<script src="/Public/js/jquery-1.9.1.min.js"></script>
<script src="/Public/js/bootstrap.min.js"></script>
<script src="/Public/js/common.js"></script>
<style>
div.form-group{
    margin-bottom: 8px;
}
</style>

<!--<div class="right-container">-->
<div style="padding: 10px;">
    <form id="soft" method="post" onsubmit="soft_submit();return false;">
        <input type="text" hidden="hidden" name="sid" value="<?php echo ($sid); ?>">
        <label>软件名称</label>
        <div class="form-group input-group-half">
            <input type="text" class="form-control" name="software" value="<?php echo ($software); ?>" placeholder="请输入软件名">
        </div>
        <label>试用分钟</label>
        <div class="form-group input-group-half"  >
            <input type="text" class="form-control" name="try_minutes" value="<?php echo ($try_minutes); ?>" placeholder="填0代表不可试用">
        </div>
        <label>试用次数</label>
        <div class="form-group input-group-half" >
            <input type="text" class="form-control" name="try_count" value="<?php echo ($try_count); ?>" placeholder="填0代表不可试用">
        </div>
        <div class="form-group" >
            <label class="control-label ng-scope">绑机多开模式</label>
            <div class="custom-form-inline custom-form-horizontal-form">
                <div class="radio custom-control">
                    <label>
                        <input type="radio" value="0" class="ng-pristine ng-valid" name="bindmode" <?php echo ($bindmode0); ?>>
                        <span class="control-indicator"></span>
                        绑机单开
                    </label>
                </div>
                <div class="radio custom-control">
                    <label>
                        <input type="radio" value="1" class="ng-pristine ng-valid" name="bindmode" <?php echo ($bindmode1); ?>>
                        <span class="control-indicator"></span>
                        绑机多开
                    </label>
                </div>

                <div class="radio custom-control">
                    <label>
                        <input type="radio" value="2" class="ng-pristine ng-valid" name="bindmode" <?php echo ($bindmode2); ?>>
                        <span class="control-indicator"></span>
                        不绑机多开
                    </label>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label class="control-label ng-scope">用户解绑模式</label>
            <div class="custom-form-inline custom-form-horizontal-form">
                <div class="radio custom-control">
                    <label>
                        <input type="radio" value="0" class="ng-pristine ng-valid" name="unbindmode" <?php echo ($unbindmode0); ?>>
                        <span class="control-indicator"></span>
                        允许解绑
                    </label>
                </div>
                <div class="radio custom-control">
                    <label>
                        <input type="radio" value="1" class="ng-pristine ng-valid" name="unbindmode" <?php echo ($unbindmode1); ?>>
                        <span class="control-indicator"></span>
                        不允许解绑
                    </label>
                </div>
            </div>
        </div>
        
        
        <div class="form-group">
            <label class="control-label ng-scope">软件本地是否开启试用</label>
            <div class="custom-form-inline custom-form-horizontal-form">
                <div class="radio custom-control">
                    <label>
                        <input type="radio" value="0" class="ng-pristine ng-valid" name="sy" <?php echo ($sy0); ?>>
                        <span class="control-indicator"></span>
                        开启
                    </label>
                </div>
                <div class="radio custom-control">
                    <label>
                        <input type="radio" value="1" class="ng-pristine ng-valid" name="sy" <?php echo ($sy1); ?>>
                        <span class="control-indicator"></span>
                        关闭
                    </label>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label class="control-label ng-scope">软件本地是否开启发卡网</label>
            <div class="custom-form-inline custom-form-horizontal-form">
                <div class="radio custom-control">
                    <label>
                        <input type="radio" value="0" class="ng-pristine ng-valid" name="web" <?php echo ($web0); ?>>
                        <span class="control-indicator"></span>
                        开启
                    </label>
                </div>
                <div class="radio custom-control">
                    <label>
                        <input type="radio" value="1" class="ng-pristine ng-valid" name="web" <?php echo ($web1); ?>>
                        <span class="control-indicator"></span>
                        关闭
                    </label>
                </div>
            </div>
        </div>
        <div class="form-group">
            <label class="control-label ng-scope">软件本地是否开启顶部广告条</label>
            <div class="custom-form-inline custom-form-horizontal-form">
                <div class="radio custom-control">
                    <label>
                        <input type="radio" value="0" class="ng-pristine ng-valid" name="showad" <?php echo ($showad0); ?>>
                        <span class="control-indicator"></span>
                        开启
                    </label>
                </div>
                <div class="radio custom-control">
                    <label>
                        <input type="radio" value="1" class="ng-pristine ng-valid" name="showad" <?php echo ($showad1); ?>>
                        <span class="control-indicator"></span>
                        关闭
                    </label>
                </div>
            </div>
        </div>
        <label>发卡网地址</label>
        <div class="form-group input-group-half">
            <input type="text" class="form-control" name="weburl" value="<?php echo ($weburl); ?>" placeholder="发卡网地址">
        </div>
        <label>软件标题</label>
        <div class="form-group input-group-half">
            <input type="text" class="form-control" name="title" value="<?php echo ($title); ?>" placeholder="软件标题">
        </div>
        <label>输入框提示内容</label>
        <div class="form-group input-group-half">
            <input type="text" class="form-control" name="hint" value="<?php echo ($hint); ?>" placeholder="输入框提示信息">
        </div>
        <label>软件字体颜色</label>
        <div class="form-group input-group-half">
            <input type="color" class="form-control" name="textcolor" value="<?php echo ($textcolor); ?>" placeholder="例子   #000000">
        </div>
        <label>抽代码Key</label>
        <div class="form-group input-group-half">
            <input type="text" class="form-control" name="jmkey" value="<?php echo ($jmkey); ?>" placeholder="">
        </div>
        
        <label>软件版本</label>
        <div class="form-group input-group-half">
            <input type="text" class="form-control" name="version" value="<?php echo ($version); ?>" placeholder="请输入非负整数">
        </div>
        <label>更新地址</label>
        <div class="form-group input-group-half">
            <input type="text" class="form-control" name="update_url" value="<?php echo ($update_url); ?>" placeholder="请输入url地址">
        </div>
        <label>更新提示内容</label>
        <div class="form-group input-group-half">
                    <textarea class="form-control ng-pristine ng-valid" rows="4" name="updatamsg"><?php echo ($updatamsg); ?></textarea>
        </div>
        
        <div class="form-group">
            <label class="control-label ng-scope">更新模式</label>
            <div class="custom-form-inline custom-form-horizontal-form">
                <div class="radio custom-control">
                    <label>
                        <input type="radio" value="0" class="ng-pristine ng-valid" name="updatemode" <?php echo ($updatemode0); ?>>
                        <span class="control-indicator"></span>
                        不强制更新
                    </label>
                </div>
                <div class="radio custom-control">
                    <label>
                        <input type="radio" value="1" class="ng-pristine ng-valid" name="updatemode" <?php echo ($updatemode1); ?>>
                        <span class="control-indicator"></span>
                        强制更新
                    </label>
                </div>
            </div>
        </div>
        
        <label>软件公告</label>
        <div class="form-group input-group-half ng-scope">
        <textarea class="form-control ng-pristine ng-valid" rows="4" name="info"><?php echo ($info); ?></textarea>
        </div>
        <div class="form-group">
            <label class="control-label ng-scope">软件状态改变</label>
            <div class="custom-form-inline custom-form-horizontal-form">
                <div class="radio custom-control">
                    <label>
                        <input type="radio" value="0" class="ng-pristine ng-valid" name="frozen" <?php echo ($frozen0); ?>>
                        <span class="control-indicator"></span>
                        正常
                    </label>
                </div>
                <div class="radio custom-control">
                    <label>
                        <input type="radio" value="1" class="ng-pristine ng-valid" name="frozen" <?php echo ($frozen1); ?>>
                        <span class="control-indicator"></span>
                        禁用
                    </label>
                </div>
            </div>
        </div>
        <input type="submit" name="submit" value="<?php echo ($buttonTitle); ?>"  class="btn btn-primary" />
    </form>
</div>
<script>
    function soft_submit(){
        $.ajax({
            url: '/Home/Changesoft'
            , type: 'post'
            , data: $("#soft").serializeArray()
            , success: function(s){
                alert(s);
                if(""){

                }
            }
            , error: function (){
                //window.location.reload()
                console.log('error');
            }
        });
        return false;
    }

</script>