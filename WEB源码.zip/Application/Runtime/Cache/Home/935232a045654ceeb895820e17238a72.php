<?php if (!defined('THINK_PATH')) exit();?><div class="layuimini-container">
    <div class="layuimini-main">
	    <div class="layui-btn-group">
            <button class="layui-btn data-add-btn">添加新公告</button>
        </div>
		<table class="layui-hide" id="currentTableId" lay-filter="currentTableFilter"></table>
        <script type="text/html" id="currentTableBar">
            <a class="layui-btn layui-btn-xs data-count-edit" lay-event="edit">编辑</a>
            <a class="layui-btn layui-btn-xs layui-btn-danger data-count-delete" lay-event="delete">删除</a>
        </script>
    </div>
</div>
<script class="EditNoticeInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="NoticeInfo">
		                 <div class="layui-hide">
                              <label class="layui-form-label">ID</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled"  type="text" name="id" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">标题</label>
                              <div class="layui-input-block">
                                   <input type="text" lay-verify="required" name="title" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
		                 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">内容</label>
                              <div class="layui-input-block">
                                   <textarea name="content" lay-verify="required" class="layui-textarea"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="submit"></button>
                         </div>
				   </form>
</script>
<script class="AddNoticeInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="NoticeInfo">
		                 <div class="layui-form-item">
                              <label class="layui-form-label">标题</label>
                              <div class="layui-input-block">
                                   <input type="text" lay-verify="required" name="title" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
		                 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">内容</label>
                              <div class="layui-input-block">
                                   <textarea name="content" lay-verify="required" class="layui-textarea"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="add_Notice"></button>
                         </div>
				   </form>
</script>
<script>
    layui.use(['form', 'table'], function () {
        var $ = layui.jquery,
            form = layui.form,
            table = layui.table;
		form.render();
		//取数据
        table.render({
            elem: '#currentTableId',
            url: './Home/Gg/NoticeList',
			height: 500,
			loading: true,
			method: 'post',
			limits: [10],
            limit: 10,
			cellMinWidth: 80,
            page: true,
            cols: [[
                {field: 'id',width: 60, title: 'ID', sort: true},
				{field: 'title', title: '标题'},
                {field: 'content', title: '内容'},
				{field: 'creat_time', title: '创建时间'},
                {title: '操作', minWidth: 120, templet: '#currentTableBar', fixed: "right", align: "center"}
            ]]
        });
		$(".data-add-btn").on("click", function () {
            layer.open({
                     content: $('.AddNoticeInfo').html()
					 ,title: '发布新公告'
                     ,btn: ['提交', '取消']
					 ,success: function(layero, index){
					       form.render();
                     }
                     ,yes: function(res,layero){
					       layero.find('form').find('button[lay-submit]').click();
						   return false;
                     }
               });
        });
		form.on('submit(add_Notice)', function (data) {
		    var loading = layer.load(0, {
                        shade: false
                    });
			$.ajax({
                      url:"./Home/Gg/AddNotice",
                      method:'post',
                      data:data.field,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
                        layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
            return false;
        });
		form.on('submit(submit)', function (data) {
		    var loading = layer.load(0, {
                        shade: false
                    });
			$.ajax({
                      url:"./Home/Gg/EditNotice",
                      method:'post',
                      data:data.field,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
                        layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
            return false;
        });
        table.on('tool(currentTableFilter)', function (obj) {
            var data = obj.data;
            if (obj.event === 'edit') {
				layer.open({
                     content: $('.EditNoticeInfo').html()
					 ,title: '编辑 '+data.title
                     ,btn: ['提交修改', '取消']
					 ,success: function(layero, index){
							   form.val('NoticeInfo', {
                                        "id": data.id,
										"title": data.title,
										"content": data.content
                                        										
                               })
                     }
                     ,yes: function(res,layero){
					       layero.find('form').find('button[lay-submit]').click();
						   return false;
                     }
               });
            } else if (obj.event === 'delete') {
                layer.confirm('是否删除 '+data.title, function (index) {
                    obj.del();
                    layer.close(index);
					var loading = layer.load(0, {
                        shade: false
                    });
					$.ajax({
                      url:"./Home/Gg/NoticeDel",
                      method:'post',
                      data:data,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
                        if(result.status==0){
                           layer.msg(result.msg);
                          }
                        else
                          layer.msg(result.msg);
						layer.close(loading);
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
                });
            }
        });

    });
</script>