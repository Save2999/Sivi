<?php if (!defined('THINK_PATH')) exit();?><div class="layuimini-container">
    <div class="layuimini-main">
        <fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
            <legend>您对本网络验证的建议</legend>
        </fieldset>
        <form class="layui-form layui-form-pane" action="">
            <div class="layui-form-item layui-form-text">
                <label class="layui-form-label">内容</label>
                 <textarea placeholder="请输入内容" class="layui-textarea" name="content"></textarea>
            </div>
            <div class="layui-form-item">
                <button class="layui-btn" lay-submit="" lay-filter="login" >立即提交</button>
                <button type="reset" class="layui-btn layui-btn-primary">重置</button>
            </div>
        </form>
    </div>
</div>
<script>
    layui.use(['form', 'layedit', 'laydate'], function () {
	    var $ = layui.jquery;
        var form = layui.form
            , layer = layui.layer
            , layedit = layui.layedit
            , laydate = layui.laydate;
        form.render();
		form.on('submit(login)', function (data) {
		    var loading = layer.load(0, {
                        shade: false
                    });
            $.ajax({
                url:"./Home/Contact/submit",
                method:'post',
                data:data.field,
				xhrFields: {
                  withCredentials: true
                },
                crossDomain: true,
                dataType:'JSON',
                success:function(res){
				    var result = JSON.parse(res);
                    if(result.status==0){
                        layer.msg(result.msg);
                        location.href=location.href;
                    }
                    else
                        layer.msg(result.msg);
					
					layer.close(loading);
                },
                error:function (e) {
                    layer.msg("提交错误");
					layer.close(loading);
                }
            })
           return false;
        });
    });
</script>