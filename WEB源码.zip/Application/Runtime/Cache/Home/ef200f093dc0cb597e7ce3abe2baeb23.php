<?php if (!defined('THINK_PATH')) exit();?><div class="layuimini-container">
    <div class="layuimini-main">
	    <div class="layui-btn-group">
            <button class="layui-btn data-add-btn">添加新的注入模块</button>
        </div>
		<table class="layui-hide" id="currentTableId" lay-filter="currentTableFilter"></table>
        <script type="text/html" id="currentTableBar">
            <a class="layui-btn layui-btn-xs data-count-edit" lay-event="edit">编辑</a>
            <a class="layui-btn layui-btn-xs layui-btn-danger data-count-delete" lay-event="delete">删除</a>
        </script>
    </div>
</div>
<script class="EditModelInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="ModelInfo">
		                 <div class="layui-hide">
                              <label class="layui-form-label">ID</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled"  type="text" name="id" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
		                 <div class="layui-form-item">
                              <label class="layui-form-label">模块标题</label>
                              <div class="layui-input-block">
                                   <input type="text" name="title" lay-verify="required" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">模块描述</label>
                              <div class="layui-input-block">
                                   <textarea name="describe" lay-verify="required" class="layui-textarea"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">全局Name</label>
                              <div class="layui-input-block">
                                   <input type="text" name="whole_name" autocomplete="off" placeholder="不填代表取消全局注入" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">单例代码</label>
                              <div class="layui-input-block">
                                   <textarea name="single_code" lay-verify="required" placeholder="Smali代码 (p0为this)" class="layui-textarea"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">Dex地址</label>
                              <div class="layui-input-block">
                                   <input type="text" name="dex_url" lay-verify="required|url" autocomplete="off" placeholder="调用函数的Dex下载地址" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">资源地址</label>
                              <div class="layui-input-block">
                                   <input type="text" name="res_url" autocomplete="off" placeholder="资源文件下载地址" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">图片地址</label>
                              <div class="layui-input-block">
                                   <input type="text" name="img" lay-verify="required|url" autocomplete="off" placeholder="图片地址" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">XML结构</label>
                              <div class="layui-input-block">
                                   <textarea name="xml" placeholder="不填代表不需要修改XML" class="layui-textarea"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">配置规则</label>
                              <div class="layui-input-block">
                                   <textarea name="config_rule" lay-verify="required" placeholder="xxx:xxx/xxx=xxxx" class="layui-textarea"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">使用权限</label>
                              <div class="layui-input-block">
                                   <input type="radio" name="vip" value="0" title="普通" checked="">
                                   <input type="radio" name="vip" value="1" title="授权">
                              </div>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">运营状态</label>
                              <div class="layui-input-block">
                                   <input type="radio" name="state" value="0" title="停用" checked="">
                                   <input type="radio" name="state" value="1" title="正常">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="submit"></button>
                         </div>
				   </form>
</script>
<script class="AddModelInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="ModelInfo">
		                 <div class="layui-form-item">
                              <label class="layui-form-label">模块标题</label>
                              <div class="layui-input-block">
                                   <input type="text" name="title" lay-verify="required" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">模块描述</label>
                              <div class="layui-input-block">
                                   <textarea name="describe" lay-verify="required" class="layui-textarea"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">全局Name</label>
                              <div class="layui-input-block">
                                   <input type="text" name="whole_name" autocomplete="off" placeholder="不填代表取消全局注入" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">单例代码</label>
                              <div class="layui-input-block">
                                   <textarea name="single_code" lay-verify="required" placeholder="Smali代码 (p0为this)" class="layui-textarea"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">Dex地址</label>
                              <div class="layui-input-block">
                                   <input type="text" name="dex_url" lay-verify="required|url" autocomplete="off" placeholder="调用函数的Dex下载地址" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">资源地址</label>
                              <div class="layui-input-block">
                                   <input type="text" name="res_url" autocomplete="off" placeholder="资源文件下载地址" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">图片地址</label>
                              <div class="layui-input-block">
                                   <input type="text" name="img" lay-verify="required|url" autocomplete="off" placeholder="图片地址" class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">XML结构</label>
                              <div class="layui-input-block">
                                   <textarea name="xml" placeholder="不填代表不需要修改XML" class="layui-textarea"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item layui-form-text">
                              <label class="layui-form-label">配置规则</label>
                              <div class="layui-input-block">
                                   <textarea name="config_rule" lay-verify="required" placeholder="xxx:xxx/xxx=xxxx" class="layui-textarea"></textarea>
                              </div>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">使用权限</label>
                              <div class="layui-input-block">
                                   <input type="radio" name="vip" value="0" title="普通" checked="">
                                   <input type="radio" name="vip" value="1" title="授权">
                              </div>
                         </div>
						 <div class="layui-form-item" pane="">
                              <label class="layui-form-label">运营状态</label>
                              <div class="layui-input-block">
                                   <input type="radio" name="state" value="0" title="停用" checked="">
                                   <input type="radio" name="state" value="1" title="正常">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="add_model"></button>
                         </div>
				   </form>
</script>
<script>
    layui.use(['form', 'table'], function () {
        var $ = layui.jquery,
            form = layui.form,
            table = layui.table;
		form.render();
        table.render({
            elem: '#currentTableId',
            url: './Home/Model/ModelList',
			height: 500,
			loading: true,
			method: 'post',
			limits: [10],
            limit: 10,
			cellMinWidth: 80,
            page: true,
            cols: [[
                {field: 'id',width: 60, title: 'ID', sort: true},
				{field: 'model_type', title: '模块类型',templet:function(rec){
							if(rec.model_type=='0')
							   return "系统模块";
							else if(rec.model_type=='1')
							   return "自定义模块";
							else
							   return rec.model_type;
        		}},
                {field: 'model_title', title: '模块名'},
				{field: 'model_describe', title: '模块描述'},
				{field: 'model_state', title: '模块状态',templet:function(rec){
							if(rec.model_state=='0')
							   return "停用";
							else if(rec.model_state=='1')
							   return "正常";
							else
							   return rec.model_state;
        		}},
				{field: 'model_vip', title: '模块权限',templet:function(rec){
							if(rec.model_vip=='0')
							   return "普通用户";
							else if(rec.model_vip=='1')
							   return "授权商户";
							else
							   return rec.model_vip;
        		}},
                {title: '操作', minWidth: 120, templet: '#currentTableBar', fixed: "right", align: "center"}
            ]]
        });
		$(".data-add-btn").on("click", function () {
            layer.open({
                     content: $('.AddModelInfo').html()
					 ,title: '添加新的注入模块'
                     ,btn: ['提交', '取消']
					 ,area: '70%'
					 ,success: function(layero, index){
					       form.render();
                     }
                     ,yes: function(res,layero){
					       layero.find('form').find('button[lay-submit]').click();
						   return false;
                     }
               });
        });
		form.on('submit(add_model)', function (data) {
		    var loading = layer.load(0, {
                        shade: false
                    });
			$.ajax({
                      url:"./Home/Model/AddModel",
                      method:'post',
                      data:data.field,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
                        layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
            return false;
        });
		form.on('submit(submit)', function (data) {
		    var loading = layer.load(0, {
                        shade: false
                    });
			$.ajax({
                      url:"./Home/Model/EditModel",
                      method:'post',
                      data:data.field,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
                        layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
            return false;
        });
        table.on('tool(currentTableFilter)', function (obj) {
            var data = obj.data;
            if (obj.event === 'edit') {
				layer.open({
                     content: $('.EditModelInfo').html()
					 ,title: '编辑 '+data.model_title
					 ,area: '70%'
                     ,btn: ['提交修改', '取消']
					 ,success: function(layero, index){
					           form.render();
							   form.val('ModelInfo', {
                                        "id": data.id,
										"title": data.model_title,
										"describe": data.model_describe,
										"whole_name": data.model_whole_name,
										"single_code": data.model_single_code,
										"dex_url": data.model_dex_url,
										"res_url": data.model_res_url,
										"xml": data.model_xml,
										"state": data.model_state,
										"img": data.model_img,
										"config_rule": data.model_config_rule,
										"vip": data.model_vip
                                        										
                               })
                     }
                     ,yes: function(res,layero){
					       layero.find('form').find('button[lay-submit]').click();
						   return false;
                     }
               });
            } else if (obj.event === 'delete') {
                layer.confirm('是否删除 '+data.model_title, function (index) {
                    obj.del();
                    layer.close(index);
					var loading = layer.load(0, {
                        shade: false
                    });
					$.ajax({
                      url:"./Home/Model/ModelDel",
                      method:'post',
                      data:data,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
						layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
                });
            }
        });

    });
</script>