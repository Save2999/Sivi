<?php if (!defined('THINK_PATH')) exit();?><div class="layuimini-container">
    <div class="layuimini-main">
	    <div class="layui-btn-group">
            <button class="layui-btn data-add-btn">设置代理软件开卡价格</button>
        </div>
		<table class="layui-hide" id="currentTableId" lay-filter="currentTableFilter"></table>
        <script type="text/html" id="currentTableBar">
            <a class="layui-btn layui-btn-xs data-count-edit" lay-event="edit">编辑</a>
            <a class="layui-btn layui-btn-xs layui-btn-danger data-count-delete" lay-event="delete">删除</a>
        </script>
    </div>
</div>
<script class="EditPriceInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="PriceInfo">
		                 <div class="layui-hide">
                              <label class="layui-form-label">ID</label>
                              <div class="layui-input-inline">
                                   <input disabled="disabled"  type="text" name="id" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
		                 <div class="layui-form-item">
                              <label class="layui-form-label">小时卡</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|number" name="hour" autocomplete="off"  class="layui-input">
                              </div>
                         </div> 
						 <div class="layui-form-item">
                              <label class="layui-form-label">天卡</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|number" name="day" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">月卡</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|number" name="month" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">季卡</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|number" name="season" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">年卡</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|number" name="year" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="edit_price"></button>
                         </div>
				   </form>
</script>
<script class="AddPriceInfo" type="text/html">
          <form class="layui-form layui-form-pane" action="" lay-filter="PriceInfo">
		                <div class="layui-form-item">
			                 <div class="layui-inline">
                             <label class="layui-form-label">代理选择</label>
                             <div class="layui-input-inline">
                                  <select lay-verify="required" name="proxy_id" lay-reqtext="代理都不选择，你想干嘛？">
						                    <option value="">请选择代理</option>
						                    <?php if(is_array($proxylist)): $i = 0; $__LIST__ = $proxylist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>"><?php echo ($vo["username"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                                  </select>
                             </div>
                             </div>
			             </div>
		                <div class="layui-form-item">
			                 <div class="layui-inline">
                             <label class="layui-form-label">软件选择</label>
                             <div class="layui-input-inline">
                                  <select lay-verify="required" name="soft_id" lay-reqtext="软件都不选择，你想干嘛？">
						                    <option value="">请选择软件</option>
						                    <?php if(is_array($softlist)): $i = 0; $__LIST__ = $softlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>"><?php echo ($vo["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                                  </select>
                             </div>
                             </div>
			             </div>
		                 <div class="layui-form-item">
                              <label class="layui-form-label">小时卡</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|number" name="hour" autocomplete="off"  class="layui-input">
                              </div>
                         </div> 
						 <div class="layui-form-item">
                              <label class="layui-form-label">天卡</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|number" name="day" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">月卡</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|number" name="month" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">季卡</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|number" name="season" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <label class="layui-form-label">年卡</label>
                              <div class="layui-input-inline">
                                   <input type="text" lay-verify="required|number" name="year" autocomplete="off"  class="layui-input">
                              </div>
                         </div>
						 <div class="layui-form-item">
                              <button class="layui-hide"  lay-submit="" lay-filter="add_price"></button>
                         </div>
				   </form>
</script>

<script>
    layui.config({
        base: '/static/js/'
    }).extend({
        formSelects: 'formSelects-v4'
    });
    layui.use(['form', 'table', 'formSelects'], function () {
	    var formSelects = layui.formSelects;
        var $ = layui.jquery,
            form = layui.form,
            table = layui.table;
		
		form.render();
        table.render({
            elem: '#currentTableId',
            url: './Home/Price/PriceList',
			height: 500,
			loading: true,
			method: 'post',
			limits: [10],
            limit: 10,
			cellMinWidth: 80,
            page: true,
            cols: [[
                {field: 'id',width: 60, title: 'ID', sort: true},
                {field: 'proxy_id', title: '代理账号ID'},
				{field: 'proxy_name', title: '代理账号'},
				{field: 'soft_id', title: '代理软件ID'},
				{field: 'soft_name', title: '代理软件'},
				{field: 'hour', title: '小时卡'},
				{field: 'day', title: '天卡'},
				{field: 'month', title: '月卡'},
				{field: 'season', title: '季卡'},
				{field: 'year', title: '年卡'},
                {title: '操作', minWidth: 120, templet: '#currentTableBar', fixed: "right", align: "center"}
            ]]
        });
		$(".data-add-btn").on("click", function () {
            layer.open({
                     content: $('.AddPriceInfo').html()
					 ,title: '设置代理软件开卡价格'
                     ,btn: ['提交', '取消']
					 ,success: function(layero, index){
					       form.render();
                     }
                     ,yes: function(res,layero){
					       layero.find('form').find('button[lay-submit]').click();
						   return false;
                     }
               });
        });
		form.on('submit(add_price)', function (data) {
		    var loading = layer.load(0, {
                        shade: false
                    });
			$.ajax({
                      url:"./Home/Price/AddPrice",
                      method:'post',
                      data:data.field,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
                        layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
            return false;
        });
		form.on('submit(edit_price)', function (data) {
		    var loading = layer.load(0, {
                        shade: false
                    });
			$.ajax({
                      url:"./Home/Price/EditPrice",
                      method:'post',
                      data:data.field,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
						layer.close(loading);
                        layer.msg(result.msg,{
                            time:1000,
                            end:function () {
                            window.location.reload();
                            }
                        });
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
            return false;
        });
        table.on('tool(currentTableFilter)', function (obj) {
            var data = obj.data;
            if (obj.event === 'edit') {
				layer.open({
                     content: $('.EditPriceInfo').html()
					 ,title: '编辑'
                     ,btn: ['提交修改', '取消']
					 ,success: function(layero, index){
					           form.render();
							   form.val('PriceInfo', {
                                        "id": data.id,
										"hour": data.hour,
										"day": data.day,
										"month": data.month,
										"season": data.season,
										"year": data.year
                                        										
                               });
                     }
                     ,yes: function(res,layero){
					       layero.find('form').find('button[lay-submit]').click();
						   return false;
                     }
               });
            } else if (obj.event === 'delete') {
                layer.confirm('是否删除ID:'+data.id+' 这条记录', function (index) {
                    obj.del();
                    layer.close(index);
					var loading = layer.load(0, {
                        shade: false
                    });
					$.ajax({
                      url:"./Home/Price/PriceDel",
                      method:'post',
                      data:data,
				      xhrFields: {
                      withCredentials: true
                      },
                      crossDomain: true,
                      dataType:'JSON',
                      success:function(res){
				        var result = JSON.parse(res);
                        if(result.status==0){
                           layer.msg(result.msg);
                          }
                        else
                          layer.msg(result.msg);
						layer.close(loading);
                    },
                    error:function (e) {
                       layer.msg("提交错误");
					   layer.close(loading);
                    }
                  })
                });
            }
        });

    });
</script>