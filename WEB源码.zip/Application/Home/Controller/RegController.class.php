<?php

namespace Home\Controller;

use Common\Controller\BaseController;
use hdphp\page\Page;
use Home\Tool\HJCTool;

class RegController extends BaseController
{
    public function index()
    {
        $this->reg();
        $this->display();
    }

    private function reg()
    {
        if (!isset($_POST['reg'])) {
            return;
        }
        if (I('post.valid') == '') {
            // 这里不用alertBack因为需要刷新页面
            HJCTool::alertToLocation('请输入验证码', '/Home/reg');
            return;
        }
        if (!$this->check_verify(I('post.valid'))) {
            HJCTool::alertToLocation('验证码错误', '/Home/reg');
        }
        if (I('post.username', '', '/^[a-z0-9A-Z]{6,16}$/') == '') {
            HJCTool::alertToLocation('账号格式错误: 请输入6-16位英文字母或数字', '/Home/reg');
        }
        if (I('post.password', '', '/^[a-z0-9A-Z]{6,16}$/') == '') {
            HJCTool::alertToLocation('密码格式错误: 请输入6-16位英文字母或数字', '/Home/reg');
        }
        if (I('post.email', '', FILTER_VALIDATE_EMAIL) == '') {
            HJCTool::alertToLocation('邮箱格式错误', '/Home/reg');
        }
        $username = I('post.username');
        $password = HJCTool::secret(I('post.password'));
        $email = I('post.email');

        $mysql = M('user');
        if ($mysql->query("SELECT * FROM cloud_user WHERE username='" . $username . "'")) {
            HJCTool::alertBack('此用户名已存在');
        }

        $ret = $mysql->execute("INSERT INTO cloud_user (username, password, email, reg_time, vip) VALUES ('$username', '$password', '$email', NOW(),false)");
        if ($ret) {
            HJCTool::alertToLocation('注册成功!', '/Home/login');
        }
    }

    public function Register()
    {
        if (!$this->check_verify(I('post.captcha'))) {
            $date = [
                'status' => 0,
                'msg' => '验证码错误'
            ];
            $this->ajaxReturn(json_encode($date), 'JSON');
        }
        if ($this->isEmpty(I('post.username', '', '/^[a-z0-9A-Z]{6,16}$/'))) {
            $date = [
                'status' => 0,
                'msg' => '账号格式错误: 请输入6-16位英文字母或数字'
            ];
            $this->ajaxReturn(json_encode($date), 'JSON');
        }
        if ($this->isEmpty(I('post.password', '', '/^[a-z0-9A-Z]{6,16}$/'))) {
            $date = [
                'status' => 0,
                'msg' => '密码格式错误: 请输入6-16位英文字母或数字'
            ];
            $this->ajaxReturn(json_encode($date), 'JSON');
        }
        $username = I('post.username');
        $password = HJCTool::secret(I('post.password'));
        $email = I('post.email');
        $mysql = M('User');
        if ($mysql->where("username='" . $username . "'")->find()) {
            $date = [
                'status' => 0,
                'msg' => '用户已存在'
             ];
		    $this->ajaxReturn(json_encode($date),'JSON');
        }
		if($username == C('ADMIN_USER')){
			$time = new \DateTime('2099-12-30 00:00:00');
			$expire_time = date('Y-m-d H:i:s', $time->format("U"));
		} else {
			$expire_time = date('Y-m-d H:i:s', time()+(C('GIVE')*60));
		}
        $mysql->username = $username;
        $mysql->password = $password;
        $mysql->email = $email;
        $mysql->reg_time = date('Y-m-d H:i:s', time());
        $mysql->expire_time = $expire_time;
        $mysql->vip = 1;
        $ret = $mysql->add();
        if ($ret) {
            $date = [
                'status' => 1,
                'msg' => '注册成功'
            ];
            $this->ajaxReturn(json_encode($date), 'JSON');
        }
    }

}