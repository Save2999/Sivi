<?php
namespace Home\Controller;
use Common\Controller\BaseController;
use Home\Tool\HJCTool;

class ManagesoftController extends BaseController {

    public function index(){
        $this->assign('managesoft_selected', 'selected');
        // 把当前页数传到tpl,在请求的时候可以带过来,以便删除商品后刷新在当前页
        $this->assign('querystr', $this->_lastQueryStr);

        parent::showTableAndPage('software',null);
        $this->deleteSoft();
        $this->display();

    }

//    private function deleteSoft(){
//        if (I('delsid') == '') return;
//
//        $sid = I('delsid');
//        $userId = $this->getUserId();
//        $mysql = M('Software');
//        $updateret = $mysql->execute("DELETE FROM cloud_software WHERE id = '$sid' AND user_id = '$userId'");
//        if ($updateret) {
//            // 删除对应的注册码
//            $mysql = M('Regcode');
//            $updateret = $mysql->execute("DELETE FROM cloud_regcode WHERE software_id = '$sid' AND user_id = '$userId'");
//            // 不去判断有没有删除成功了,没有注册码会返回flase
//            if (I('page') == '') {
//                HJCTool::alertToLocation('删除成功', 'managesoft');
//            } else {
//                HJCTool::alertToLocation('删除成功', 'managesoft?page=' . I('page'));
//            }
//        } else {
//            HJCTool::alertBack('删除失败');
//        }
//    }

    public function SoftList(){
        if (I('post.page') == '') {
            return;
        }
        if (I('post.limit') == '') {
            return;
        }
        $search = null;
        if (I('post.searchParams') != '') {
            $json = I('post.searchParams');
            $json = html_entity_decode($json);
            $json = stripslashes($json);
            $search = json_decode($json,true);
        }
        $this->_currentPage = I('post.page/d');
        $this->_itemCountAPage = I('post.limit/d');
        $userId = $this->getUserId();
        $mysql = M('Software');
        $ret = $mysql->where("user_id = '$userId'")->select();
        if ($search == null) {
            $list = $mysql->where("user_id = '$userId'")->limit(abs($this->_currentPage-1) * $this->_itemCountAPage . ", " . $this->_itemCountAPage)->select();
        } else {
            $list = $mysql->where("user_id = '$userId' AND name = '{$search['name']}'")->select();
        }
        $date=[
            'code'=>0,
            'msg'=>'',
            'count' => sizeof($ret),
            "data" => $list
        ];
        echo json_encode($date);
    }

    public function DeleteSoft(){
        if (I('post.id') == '') return;
        $sid = I('post.id');
        $userId = $this->getUserId();
        $mysql = M('Software');
        $updateret = $mysql->where("id = '$sid' AND user_id = '$userId'")->delete();
        if ($updateret) {
            $mysql = M('Regcode');
            $mysql->where("software_id = '$sid' AND user_id = '$userId'")->delete();
            $date=[
                'status'=>0,
                'msg'=>'删除成功'
            ];
            $this->ajaxReturn(json_encode($date),'JSON');
        } else {
            $date=[
                'status'=>1,
                'msg'=>'删除失败'
            ];
            $this->ajaxReturn(json_encode($date),'JSON');
        }
    }
    public function EditSoft(){
        if (I('post.id') == '') return;
        $this->EditAuth();
    }
    private function EditAuth(){
        $sid = I('post.id');
        $name = trim(I('post.name'));
        $mysql = M('Software');
        $ret = $mysql->create();
        $updateret = $mysql->where("id = '$sid'")->save($ret);
        if (!$updateret) {
            $date=[
                'status'=> 1,
                'msg'=>'修改失败'
            ];
            $this->ajaxReturn(json_encode($date),'JSON');
        } else {
            $mysql = M('Regcode');
            $mysql->where("software_id = '{$sid}'")->setField('software_name',$name);
            $date=[
                'status'=> 0,
                'msg'=>'修改成功'
            ];
            $this->ajaxReturn(json_encode($date),'JSON');
        }
    }
}