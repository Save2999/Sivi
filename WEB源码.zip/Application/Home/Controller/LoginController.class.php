<?php
namespace Home\Controller;

use Common\Controller\BaseController;
use hdphp\page\Page;
use Home\Tool\HJCTool;

class LoginController extends BaseController {
    public function index() {
//        dump(HJCTool::secret('admin123'));
        $this->init();
        $this->display();
    }

    private function init() {
        if (!isset($_POST['login'])) {
            return;
        }
        if (I('post.valid') == '') {
            // 这里不用alertBack因为需要刷新页面
            HJCTool::alertToLocation('请输入验证码', '/Home/login');
            return;
        }
        if (!$this->check_verify(I('post.valid'))) {
            HJCTool::alertToLocation('验证码错误', '/Home/login');
        }
        if ($this->isEmpty(I('post.username', '', '/^[a-z0-9A-Z]{6,16}$/'))) {
            HJCTool::alertToLocation('账号格式错误: 请输入6-16位英文字母或数字', '/Home/login');
        }
        if ($this->isEmpty(I('post.password', '', '/^[a-z0-9A-Z]{6,16}$/'))) {
            HJCTool::alertToLocation('密码格式错误: 请输入6-16位英文字母或数字', '/Home/login');
        }
        $username = I('post.username');
        $password = HJCTool::secret(I('post.password'));

        $mysql = M('user');
        $user_ret = $mysql->query("SELECT * FROM cloud_user WHERE username='" . $username . "'");
        if (!$user_ret) {
            HJCTool::alertBack('用户名不存在');
        } else {
            if ($user_ret[0]['password'] != $password) {
                HJCTool::alertBack('密码不正确');
            }else if ($user_ret[0]['vip'] == 0) {
                HJCTool::alertBack('商户未审核 请联系QQ2028383846进行审核');
            }
        }

        $id = $user_ret[0]['id'];
        $lastlogin_time = $user_ret[0]['currentlogin_time'] ? : date('Y-m-d H:i:s', time());
        $lastlogin_ip = $user_ret[0]['currentlogin_ip'];
        $currentlogin_ip = HJCTool::getRealIP();
        $currentlogin_time = date('Y-m-d H:i:s', time());
        $login_count = $user_ret[0]['login_count'] + 1;

        $ret = $mysql->execute("UPDATE cloud_user SET lastlogin_time = '$lastlogin_time', lastlogin_ip = '$lastlogin_ip', currentlogin_time = '$currentlogin_time', currentlogin_ip = '$currentlogin_ip', login_count = '$login_count' WHERE id = '$id'");
        if ($ret) {
            $_SESSION['user'] = $username;
            $_SESSION['last_logn_time'] = time();
            HJCTool::alertToLocation(null, '/Home');
        } else {
            HJCTool::alertBack('数据库异常');
        }
    }

    public function Login() {
        if (!$this->check_verify(I('post.captcha'))) {
            $date=[
                'status'=>0,
                'msg'=>'验证码错误'
            ];
            $this->ajaxReturn(json_encode($date),'JSON');
        }
        if ($this->isEmpty(I('post.username', '', '/^[a-z0-9A-Z]{6,16}$/'))) {
            $date=[
                'status'=>0,
                'msg'=>'账号格式错误: 请输入6-16位英文字母或数字'
            ];
            $this->ajaxReturn(json_encode($date),'JSON');
        }
        if ($this->isEmpty(I('post.password', '', '/^[a-z0-9A-Z]{6,16}$/'))) {
            $date=[
                'status'=>0,
                'msg'=>'密码格式错误: 请输入6-16位英文字母或数字'
            ];
            $this->ajaxReturn(json_encode($date),'JSON');
        }
        $username = I('post.username');
        $password = HJCTool::secret(I('post.password'));
        $mysql = M('User');
        $user_ret = $mysql->where("username = '" . $username . "'")->find();
        if (!$user_ret) {
            $date=[
                'status'=>0,
                'msg'=>'用户不存在'
            ];
            $this->ajaxReturn(json_encode($date),'JSON');
        } else {
            if ($user_ret['password'] != $password) {
                $date=[
                    'status'=>0,
                    'msg'=>'密码不正确'
                ];
                $this->ajaxReturn(json_encode($date),'JSON');
            }
            if ($user_ret['vip'] == 0) {
                $date=[
                    'status'=>0,
                    'msg'=>'商户未审核 请联系QQ XX 进行审核'
                ];
                $this->ajaxReturn(json_encode($date),'JSON');
            }
            if (strtotime(date('Y-m-d H:i:s', time())) - strtotime($user_ret['expire_time']) > 0) {
                $date=[
                    'status'=>0,
                    'msg'=>'账号已到期'
                ];
                $this->ajaxReturn(json_encode($date),'JSON');
            }
        }

        $id = $user_ret['id'];
        $lastlogin_time = $user_ret['currentlogin_time'] ? : date('Y-m-d H:i:s', time());
        $lastlogin_ip = $user_ret['currentlogin_ip'];
        $currentlogin_ip = HJCTool::getRealIP();
        $currentlogin_time = date('Y-m-d H:i:s', time());
        $login_count = $user_ret['login_count'] + 1;
        $mysql->lastlogin_time = $lastlogin_time;
        $mysql->lastlogin_ip = $lastlogin_ip;
        $mysql->currentlogin_ip = $currentlogin_ip;
        $mysql->currentlogin_time = $currentlogin_time;
        $mysql->login_count = $login_count;
        $ret = $mysql->where("id = '$id'")->save();
        if ($ret) {
            $_SESSION['user'] = $username;
            $_SESSION['last_logn_time'] = time();
            $date=[
                'status'=>1,
                'msg'=>'登录成功 欢迎使用'.C('NAME')
            ];
            $this->ajaxReturn(json_encode($date),'JSON');
        } else {
            $date=[
                'status'=>0,
                'msg'=>'登录失败 未知异常'
            ];
            $this->ajaxReturn(json_encode($date),'JSON');
        }
    }

}