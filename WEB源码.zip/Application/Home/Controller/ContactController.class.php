<?php
namespace Home\Controller;

use Common\Controller\BaseController;
use Home\Tool\HJCTool;

class ContactController extends BaseController {

    public function index() {
        $this->assign('contact_selected', 'selected');
        $this->init();
        $this->display();
    }

    private function init() {
        if (!I('content')) {
            return;
        }

        $userID = $this->getUserId();
        $submitTime = date('Y-m-d H:i:s', time());
        $submitIP = HJCTool::getRealIP();
        $content = I('content');

        $mysql = M();
        $mysql->execute("INSERT INTO cloud_advise SET user_id = '$userID', submit_time = '$submitTime', submit_ip = '$submitIP', content = '$content'");
        HJCTool::alertToLocation('感谢您宝贵的建议!', '/Home/contact');
    }

    public function submit() {
        if (I('post.content') == '') {
            return;
        }
        $username = $this->getUser()['username'];
        $user_id = $this->getUser()['id'];
        $submitTime = date('Y-m-d H:i:s', time());
        $submitIP = HJCTool::getRealIP();
        $content = I('post.content');
        $mysql = M('Advise');
        $mysql->username = $username;
        $mysql->user_id = $user_id;
        $mysql->content = $content;
        $mysql->submit_ip = $submitIP;
        $mysql->submit_time = $submitTime;
        $mysql->add();
        $date=[
            'status'=>0,
            'msg'=>'提交成功'
        ];
        $this->ajaxReturn(json_encode($date),'JSON');
    }
}