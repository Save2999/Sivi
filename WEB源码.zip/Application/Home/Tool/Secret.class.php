<?php
namespace Home\Tool;

class Secret {
    public function createRandRegisterCode() {
        $yz = 'abcdefghijklmnopkrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()_+,.?';
        $str = '';
        $yz .= $yz;$yz .= $yz;$yz .= $yz;$yz .= $yz;$yz .= $yz;$yz .= $yz;$yz .= $yz;$yz .= $yz;$yz .= $yz;$yz .= $yz;$yz .= $yz;$yz .= $yz;$yz .= $yz;$yz .= $yz;
        for ($i = 0; $i< 16; $i++) {
            $index = mt_rand(0, strlen($yz) - 1);
            $str = $str . $yz[$index];
        }
        return substr(strtoupper(md5($str)),0,24);
    }

}